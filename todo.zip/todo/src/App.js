import TodoScreen from "./Components/todoScreen/TodoScreen";
import "./App.css";

function App() {
  return (
    <div className="App">
      <TodoScreen></TodoScreen>
    </div>
  );
}

export default App;
